module.exports = TempFiles = class {
    static sendTempsFiles(myId, otherId, file){
        return new Promise((next)=>{
            console.log(file)
        })
    }
}

